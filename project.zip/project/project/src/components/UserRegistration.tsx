import React, { useState } from 'react';
import { useUser } from '../contexts/UserContext';

interface UserRegistrationProps {
  onComplete: () => void;
}

const UserRegistration: React.FC<UserRegistrationProps> = ({ onComplete }) => {
  const { setUserName } = useUser();
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      setError('Please enter your name');
      return;
    }
    
    // Set the user name in context (this will also generate a UID)
    setUserName(name.trim());
    
    // Notify parent component that registration is complete
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-[#111111] border border-[#B026FF]/30 rounded-lg w-full max-w-md p-6 shadow-[0_0_20px_rgba(176,38,255,0.3)]">
        <h2 className="text-2xl font-semibold mb-6 text-[#CDA2FC]">Welcome to UnifiedChain ID</h2>
        
        <p className="text-gray-300 mb-6">
          Create your unified identity to manage all your blockchain wallets in one place.
        </p>
        
        <form onSubmit={handleSubmit}>
          <div className="mb-6">
            <label htmlFor="userName" className="block text-sm font-medium text-gray-300 mb-2">
              Your Name
            </label>
            <input
              type="text"
              id="userName"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
            />
            {error && (
              <p className="mt-2 text-red-400 text-sm">{error}</p>
            )}
          </div>
          
          <div className="flex justify-end">
            <button
              type="submit"
              className="px-6 py-3 bg-gradient-to-r from-[#B026FF] to-[#B026FF]/50 text-white rounded-md hover:shadow-[0_0_15px_rgba(176,38,255,0.6)] transition-all duration-300"
            >
              Create My Identity
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserRegistration;
