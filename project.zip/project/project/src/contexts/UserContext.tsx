import React, { createContext, useContext, useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid'; // We'll need to install this package

// Define the Wallet interface
interface Wallet {
  id: string;
  name: string;
  icon: string;
  address: string;
  seedPhrase?: string;
  privateKey?: string;
}

// Define the context type
interface UserContextType {
  userName: string;
  setUserName: (name: string) => void;
  uid: string;
  connectedWallets: Wallet[];
  addWallet: (wallet: Wallet) => void;
  removeWallet: (walletId: string) => void;
  updateWallet: (walletId: string, updates: Partial<Wallet>) => void;
  isUserRegistered: boolean;
}

// Create the context with default values
const UserContext = createContext<UserContextType>({
  userName: '',
  setUserName: () => {},
  uid: '',
  connectedWallets: [],
  addWallet: () => {},
  removeWallet: () => {},
  updateWallet: () => {},
  isUserRegistered: false,
});

// Custom hook to use the user context
export const useUser = () => useContext(UserContext);

// Generate a cryptographically secure UID
const generateUID = (): string => {
  // Generate a UUID v4
  const uuid = uuidv4();
  
  // Convert to a more user-friendly format (uppercase alphanumeric without dashes)
  return uuid.replace(/-/g, '').toUpperCase().substring(0, 16);
};

// Provider component
export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state from localStorage if available
  const [userName, setUserName] = useState<string>(() => {
    const storedName = localStorage.getItem('ucid_userName');
    return storedName || '';
  });
  
  const [uid, setUid] = useState<string>(() => {
    const storedUid = localStorage.getItem('ucid_uid');
    return storedUid || '';
  });
  
  const [connectedWallets, setConnectedWallets] = useState<Wallet[]>(() => {
    const storedWallets = localStorage.getItem('ucid_wallets');
    return storedWallets ? JSON.parse(storedWallets) : [];
  });

  // Determine if user is registered
  const isUserRegistered = Boolean(userName && uid);

  // Update localStorage when state changes
  useEffect(() => {
    if (userName) {
      localStorage.setItem('ucid_userName', userName);
    }
  }, [userName]);

  useEffect(() => {
    if (uid) {
      localStorage.setItem('ucid_uid', uid);
    }
  }, [uid]);

  useEffect(() => {
    localStorage.setItem('ucid_wallets', JSON.stringify(connectedWallets));
  }, [connectedWallets]);

  // Set user name and generate UID if not already set
  const handleSetUserName = (name: string) => {
    setUserName(name);
    
    // Generate a new UID if one doesn't exist
    if (!uid) {
      const newUid = generateUID();
      setUid(newUid);
    }
  };

  // Add a new wallet
  const addWallet = (wallet: Wallet) => {
    setConnectedWallets(prev => [...prev, wallet]);
  };

  // Remove a wallet
  const removeWallet = (walletId: string) => {
    setConnectedWallets(prev => prev.filter(wallet => wallet.id !== walletId));
  };

  // Update a wallet
  const updateWallet = (walletId: string, updates: Partial<Wallet>) => {
    setConnectedWallets(prev => 
      prev.map(wallet => 
        wallet.id === walletId ? { ...wallet, ...updates } : wallet
      )
    );
  };

  return (
    <UserContext.Provider
      value={{
        userName,
        setUserName: handleSetUserName,
        uid,
        connectedWallets,
        addWallet,
        removeWallet,
        updateWallet,
        isUserRegistered,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};
