import React, { useState, useEffect, useRef } from 'react';
import { User, LayoutDashboard, Shield, Settings, Eye, EyeOff, X, ChevronDown, Search, Camera, CheckCircle, AlertCircle, Loader, QrCode, Scan } from 'lucide-react';
import QRCode from 'react-qr-code';
import { Html5QrcodeScanner } from 'html5-qrcode';
import { useUser } from '../contexts/UserContext';
import UserRegistration from '../components/UserRegistration';

interface Wallet {
  id: string;
  name: string;
  icon: string;
  address: string;
  seedPhrase?: string;
  privateKey?: string;
}

type WalletDetailStep = 'seedPhrase' | 'privateKey' | 'confirmation';
type WalletAction = 'show' | 'edit' | 'remove' | null;

const Dashboard: React.FC = () => {
  // Get user data from context
  const {
    userName,
    uid,
    connectedWallets: userWallets,
    addWallet,
    removeWallet,
    updateWallet,
    isUserRegistered
  } = useUser();

  const [activeTab, setActiveTab] = useState('dashboard');
  const [showUid, setShowUid] = useState(false);
  const [showWalletPopup, setShowWalletPopup] = useState(false);
  const [walletSelectionStep, setWalletSelectionStep] = useState<'select' | 'search'>('select');
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [connectedWallets, setConnectedWallets] = useState<Wallet[]>([]);
  const [showRegistration, setShowRegistration] = useState(!isUserRegistered);
  const [passwordEnabled, setPasswordEnabled] = useState(false);
  const [faceAuthEnabled, setFaceAuthEnabled] = useState(true);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showFaceAuthModal, setShowFaceAuthModal] = useState(false);
  const [userPassword, setUserPassword] = useState(''); // Store the user's password
  const [faceAuthStep, setFaceAuthStep] = useState<'scan' | 'processing' | 'success' | 'error'>('scan');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Change password modal states
  const [showChangePasswordModal, setShowChangePasswordModal] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Reveal seed phrase modal states
  const [showSeedPhraseModal, setShowSeedPhraseModal] = useState(false);
  const [seedPhrasePassword, setSeedPhrasePassword] = useState('');
  const [isPasswordVerified, setIsPasswordVerified] = useState(false);
  const [storedSeedPhrase, setStoredSeedPhrase] = useState('rapid jungle cement quote process expose improve call filter will law moon');
  const [webcamRef, setWebcamRef] = useState<React.RefObject<HTMLVideoElement> | null>(null);

  // QR code scanner states
  const [showQrScanner, setShowQrScanner] = useState(false);
  const [showQrGenerator, setShowQrGenerator] = useState(false);
  const [scanResult, setScanResult] = useState('');
  const [uidInput, setUidInput] = useState('');
  const [seedPhraseInput, setSeedPhraseInput] = useState('');
  const [showScanResultModal, setShowScanResultModal] = useState(false);
  const [qrScannerInitialized, setQrScannerInitialized] = useState(false);
  const scannerRef = useRef<HTMLDivElement>(null);

  // Effect to sync wallets from context
  useEffect(() => {
    setConnectedWallets(userWallets);
  }, [userWallets]);

  // Effect to start webcam when face auth modal opens
  useEffect(() => {
    if (showFaceAuthModal && faceAuthStep === 'scan') {
      startWebcam();
    }
  }, [showFaceAuthModal, faceAuthStep]);

  // Wallet detail modal states
  const [showWalletDetailModal, setShowWalletDetailModal] = useState(false);
  const [walletDetailStep, setWalletDetailStep] = useState<WalletDetailStep>('seedPhrase');
  const [activeWalletId, setActiveWalletId] = useState<string | null>(null);
  const [seedPhrase, setSeedPhrase] = useState<string[]>(Array(12).fill(''));
  const [privateKey, setPrivateKey] = useState('');
  const [customWalletName, setCustomWalletName] = useState('');
  const [isCustomWallet, setIsCustomWallet] = useState(false);

  // Wallet menu states
  const [menuOpenWalletId, setMenuOpenWalletId] = useState<string | null>(null);
  const [walletAction, setWalletAction] = useState<WalletAction>(null);
  const [isViewMode, setIsViewMode] = useState(false);

  // Wallet authentication states
  const [showWalletAuthModal, setShowWalletAuthModal] = useState(false);
  const [walletAuthPassword, setWalletAuthPassword] = useState('');
  const [pendingWalletId, setPendingWalletId] = useState<string | null>(null);
  const [pendingWalletAction, setPendingWalletAction] = useState<WalletAction>(null);

  // Password validation states
  const [passwordErrors, setPasswordErrors] = useState<{
    length: boolean;
    uppercase: boolean;
    number: boolean;
    special: boolean;
  }>({
    length: false,
    uppercase: false,
    number: false,
    special: false
  });
  const [newPasswordErrors, setNewPasswordErrors] = useState<{
    length: boolean;
    uppercase: boolean;
    number: boolean;
    special: boolean;
  }>({
    length: false,
    uppercase: false,
    number: false,
    special: false
  });
  const [currentPasswordError, setCurrentPasswordError] = useState<string | null>(null);

  const walletOptions = [
    { id: 'metamask', name: 'MetaMask', icon: '🦊' },
    { id: 'phantom', name: 'Phantom', icon: '👻' },
    { id: 'trustwallet', name: 'Trust Wallet', icon: '🔐' },
    { id: 'okx', name: 'OKX Wallet', icon: '🔷' },
  ];

  const connectWallet = (walletId: string) => {
    const walletToConnect = walletOptions.find(wallet => wallet.id === walletId);
    if (walletToConnect) {
      // Generate a random wallet address for demonstration
      const randomAddress = `0x${Array.from({length: 40}, () =>
        Math.floor(Math.random() * 16).toString(16)).join('')}`;

      // Add the wallet to connected wallets if not already connected
      if (!connectedWallets.some(wallet => wallet.id === walletId)) {
        const newWallet: Wallet = {
          ...walletToConnect,
          address: randomAddress
        };
        // Add to context
        addWallet(newWallet);

        // Set active wallet ID for the detail modal
        setActiveWalletId(walletId);

        // Prepare for seed phrase and private key input
        setSeedPhrase(Array(12).fill(''));
        setPrivateKey('');
        setIsViewMode(false);
        setWalletAction('edit');
        setWalletDetailStep('seedPhrase');

        // Close the wallet selection popup and open the detail modal
        setShowWalletPopup(false);
        setShowWalletDetailModal(true);
      } else {
        // If wallet is already connected, just close the popup
        setShowWalletPopup(false);
        setWalletSelectionStep('select');
        setSelectedWallet(null);
      }
    }
  };

  const toggleWalletMenu = (walletId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (menuOpenWalletId === walletId) {
      setMenuOpenWalletId(null);
    } else {
      setMenuOpenWalletId(walletId);
    }
  };

  const handleWalletAction = (action: WalletAction, walletId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpenWalletId(null);

    if (action === 'remove') {
      // Remove the wallet from context
      removeWallet(walletId);
      return;
    }

    // For show or edit actions, require authentication first
    setPendingWalletId(walletId);
    setPendingWalletAction(action);

    // Show authentication modal
    setWalletAuthPassword('');
    setShowWalletAuthModal(true);
  };

  const openWalletDetails = (walletId: string) => {
    // Store the wallet ID and action for after authentication
    setPendingWalletId(walletId);
    setPendingWalletAction('edit');

    // Show authentication modal
    setWalletAuthPassword('');
    setShowWalletAuthModal(true);
  };

  // Function to handle wallet authentication
  const handleWalletAuth = () => {
    // Check if the entered password matches the user's password
    if (userPassword && walletAuthPassword === userPassword && pendingWalletId) {
      // Authentication successful, proceed to show wallet details
      setActiveWalletId(pendingWalletId);
      setWalletDetailStep('seedPhrase');

      // Check if wallet already has seed phrase and private key
      const wallet = connectedWallets.find(w => w.id === pendingWalletId);
      if (wallet && wallet.seedPhrase) {
        setSeedPhrase(wallet.seedPhrase.split(' '));
        setPrivateKey(wallet.privateKey || '');
        setIsViewMode(true); // Default to view mode if wallet already has details
      } else {
        setSeedPhrase(Array(12).fill(''));
        setPrivateKey('');
        setIsViewMode(false); // Default to edit mode if wallet doesn't have details
      }

      setWalletAction(pendingWalletAction);

      // Close auth modal and show wallet detail modal
      setShowWalletAuthModal(false);
      setShowWalletDetailModal(true);

      // Reset pending states
      setPendingWalletId(null);
      setPendingWalletAction(null);
      setWalletAuthPassword('');

      console.log("Wallet authentication successful with password:", walletAuthPassword);
    } else {
      // Show error message for invalid password
      console.log("Authentication failed - Entered:", walletAuthPassword, "Stored:", userPassword);
      alert("Invalid password. Please try again.");
    }
  };

  const closeWalletAuthModal = () => {
    setShowWalletAuthModal(false);
    setPendingWalletId(null);
    setPendingWalletAction(null);
    setWalletAuthPassword('');
  };

  // Password validation function
  const validatePassword = (password: string, setErrors: React.Dispatch<React.SetStateAction<{
    length: boolean;
    uppercase: boolean;
    number: boolean;
    special: boolean;
  }>>) => {
    // Check for minimum length of 6 characters
    const hasMinLength = password.length >= 6;

    // Check for at least one uppercase letter
    const hasUppercase = /[A-Z]/.test(password);

    // Check for at least one number
    const hasNumber = /[0-9]/.test(password);

    // Check for at least one special character
    const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);

    // Update error states
    setErrors({
      length: !hasMinLength,
      uppercase: !hasUppercase,
      number: !hasNumber,
      special: !hasSpecial
    });

    // Return true if all criteria are met
    return hasMinLength && hasUppercase && hasNumber && hasSpecial;
  };

  // Check if password meets all requirements
  const isPasswordValid = (errors: { length: boolean; uppercase: boolean; number: boolean; special: boolean; }) => {
    return !errors.length && !errors.uppercase && !errors.number && !errors.special;
  };

  const handleSeedPhraseChange = (index: number, value: string) => {
    if (isViewMode) return; // Don't allow changes in view mode

    const newSeedPhrase = [...seedPhrase];
    newSeedPhrase[index] = value;
    setSeedPhrase(newSeedPhrase);
  };

  const handleSeedPhraseSubmit = () => {
    // Always proceed to the next step, regardless of view mode
    setWalletDetailStep('privateKey');
  };

  const handlePrivateKeySubmit = () => {
    setWalletDetailStep('confirmation');

    // Update the wallet with seed phrase and private key
    if (activeWalletId && !isViewMode) {
      // Find the wallet to update
      const wallet = connectedWallets.find(w => w.id === activeWalletId);

      if (wallet) {
        // Update the wallet in context
        updateWallet(activeWalletId, {
          seedPhrase: seedPhrase.join(' '),
          privateKey: privateKey
        });
      }
    }
  };

  const closeWalletDetailModal = () => {
    setShowWalletDetailModal(false);
    setActiveWalletId(null);
    setWalletAction(null);
    setIsCustomWallet(false);
    setCustomWalletName('');
  };

  const toggleEditMode = () => {
    setIsViewMode(!isViewMode);
  };

  const toggleFaceAuth = () => {
    if (!faceAuthEnabled) {
      // If enabling face auth, show the face auth setup modal
      setShowFaceAuthModal(true);
      setFaceAuthStep('scan');
      // Create a new webcam reference
      setWebcamRef(React.createRef<HTMLVideoElement>());
    } else {
      // If disabling face auth, just toggle it off
      setFaceAuthEnabled(false);
    }
  };

  const closeFaceAuthModal = () => {
    setShowFaceAuthModal(false);
    // Stop the webcam if it's running
    if (webcamRef && webcamRef.current && webcamRef.current.srcObject) {
      const stream = webcamRef.current.srcObject as MediaStream;
      const tracks = stream.getTracks();
      tracks.forEach(track => track.stop());
      webcamRef.current.srcObject = null;
    }
  };

  const startWebcam = async () => {
    if (webcamRef && webcamRef.current) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
            facingMode: "user"
          }
        });
        webcamRef.current.srcObject = stream;
        webcamRef.current.play();
      } catch (err) {
        console.error("Error accessing webcam:", err);
        setFaceAuthStep('error');
      }
    }
  };

  const captureAndVerifyFace = () => {
    // Simulate face detection and verification process
    setFaceAuthStep('processing');

    // Simulate processing delay
    setTimeout(() => {
      // 80% chance of success for demo purposes
      const isSuccess = Math.random() < 0.8;

      if (isSuccess) {
        setFaceAuthStep('success');
        // Wait a moment to show success message before closing
        setTimeout(() => {
          setFaceAuthEnabled(true);

          // If this was initiated from wallet authentication, proceed with wallet auth
          if (pendingWalletId) {
            // Authentication successful, proceed to show wallet details
            setActiveWalletId(pendingWalletId);
            setWalletDetailStep('seedPhrase');

            // Check if wallet already has seed phrase and private key
            const wallet = connectedWallets.find(w => w.id === pendingWalletId);
            if (wallet && wallet.seedPhrase) {
              setSeedPhrase(wallet.seedPhrase.split(' '));
              setPrivateKey(wallet.privateKey || '');
              setIsViewMode(pendingWalletAction === 'show'); // View mode if action was 'show'
            } else {
              setSeedPhrase(Array(12).fill(''));
              setPrivateKey('');
              setIsViewMode(false); // Default to edit mode if wallet doesn't have details
            }

            setWalletAction(pendingWalletAction);

            // Show wallet detail modal after face auth is closed
            setTimeout(() => {
              setShowWalletDetailModal(true);
            }, 100);

            // Reset pending states
            setPendingWalletId(null);
            setPendingWalletAction(null);
          }

          closeFaceAuthModal();
        }, 1500);
      } else {
        setFaceAuthStep('error');
      }
    }, 2000);
  };

  const togglePassword = () => {
    if (!passwordEnabled) {
      // If enabling password, show the password setup modal
      setShowPasswordModal(true);
      // Reset password fields and errors
      setPassword('');
      setConfirmPassword('');
      setPasswordErrors({
        length: false,
        uppercase: false,
        number: false,
        special: false
      });
    } else {
      // If disabling password, just toggle it off
      setPasswordEnabled(false);
    }
  };

  const handlePasswordSubmit = () => {
    // Validate password meets all requirements and matches confirmation
    const isValid = isPasswordValid(passwordErrors) && password === confirmPassword;

    if (isValid) {
      // Store the user's password
      setUserPassword(password);
      setPasswordEnabled(true);
      setShowPasswordModal(false);

      // Log to console for debugging (remove in production)
      console.log("Password set:", password);

      // Reset password fields
      setPassword('');
      setConfirmPassword('');
    }
  };

  const closePasswordModal = () => {
    setShowPasswordModal(false);
    setPassword('');
    setConfirmPassword('');
    // Reset password errors
    setPasswordErrors({
      length: false,
      uppercase: false,
      number: false,
      special: false
    });
  };

  // Handle password input with validation
  const handlePasswordInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    setPassword(newPassword);
    validatePassword(newPassword, setPasswordErrors);
  };

  const openChangePasswordModal = () => {
    setShowChangePasswordModal(true);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
    setCurrentPasswordError(null);
    setNewPasswordErrors({
      length: false,
      uppercase: false,
      number: false,
      special: false
    });
  };

  const closeChangePasswordModal = () => {
    setShowChangePasswordModal(false);
    setCurrentPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
    setCurrentPasswordError(null);
    setNewPasswordErrors({
      length: false,
      uppercase: false,
      number: false,
      special: false
    });
  };

  // Handle new password input with validation
  const handleNewPasswordInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPwd = e.target.value;
    setNewPassword(newPwd);
    validatePassword(newPwd, setNewPasswordErrors);
  };

  const handleChangePasswordSubmit = () => {
    // Check if current password matches the user's password
    if (!userPassword || currentPassword !== userPassword) {
      setCurrentPasswordError("Invalid current password");
      console.log("Password mismatch - Current:", currentPassword, "Stored:", userPassword);
      return;
    }

    // Validate new password meets all requirements and matches confirmation
    const isValid = isPasswordValid(newPasswordErrors) && newPassword === confirmNewPassword;

    if (isValid) {
      // Update the stored password
      setUserPassword(newPassword);
      setPasswordEnabled(true);
      setShowChangePasswordModal(false);

      // Log to console for debugging (remove in production)
      console.log("Password changed from:", userPassword, "to:", newPassword);

      // Reset password fields
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setCurrentPasswordError(null);
    }
  };

  const openSeedPhraseModal = () => {
    setShowSeedPhraseModal(true);
    setSeedPhrasePassword('');
    setIsPasswordVerified(false);
  };

  const closeSeedPhraseModal = () => {
    setShowSeedPhraseModal(false);
    setSeedPhrasePassword('');
    setIsPasswordVerified(false);
  };

  const verifySeedPhrasePassword = () => {
    // Check if the entered password matches the user's password
    if (userPassword && seedPhrasePassword === userPassword) {
      setIsPasswordVerified(true);
      console.log("Seed phrase password verification successful");
    } else {
      // Show error message for invalid password
      console.log("Seed phrase verification failed - Entered:", seedPhrasePassword, "Stored:", userPassword);
      alert("Invalid password. Please try again.");
    }
  };

  // QR code scanner functions
  const initializeQrScanner = () => {
    if (scannerRef.current && !qrScannerInitialized) {
      try {
        const scanner = new Html5QrcodeScanner(
          "qr-reader",
          { fps: 10, qrbox: { width: 250, height: 250 } },
          false
        );

        scanner.render(
          (decodedText) => {
            // Handle the scanned code
            setScanResult(decodedText);
            setShowScanResultModal(true);
            scanner.clear();
          },
          (error) => {
            // Handle scan failure
            console.error("QR code scan error:", error);
          }
        );

        setQrScannerInitialized(true);
      } catch (error) {
        console.error("Failed to initialize QR scanner:", error);
      }
    }
  };

  const openQrScanner = () => {
    setShowQrScanner(true);
    // Initialize scanner in the next render cycle
    setTimeout(() => {
      initializeQrScanner();
    }, 100);
  };

  const closeQrScanner = () => {
    setShowQrScanner(false);
    setQrScannerInitialized(false);
    setScanResult('');
  };

  const openQrGenerator = () => {
    setShowQrGenerator(true);
  };

  const closeQrGenerator = () => {
    setShowQrGenerator(false);
  };

  const handleScanResultSubmit = () => {
    // Process the scan result
    // In a real app, you would validate and process the scanned data
    setShowScanResultModal(false);
    // Reset scan result
    setScanResult('');
  };

  const closeScanResultModal = () => {
    setShowScanResultModal(false);
    setScanResult('');
  };

  const handleUidSubmit = () => {
    // In a real app, you would validate the UID and seed phrase
    if (uidInput && seedPhraseInput) {
      // Process the UID and seed phrase
      alert(`UID: ${uidInput}\nSeed Phrase: ${seedPhraseInput}`);
      setUidInput('');
      setSeedPhraseInput('');
      setShowQrScanner(false);
    }
  };

  const handleNotListedWallet = () => {
    // Generate a unique ID for the custom wallet
    const customWalletId = `custom-${Date.now()}`;
    setActiveWalletId(customWalletId);
    setWalletDetailStep('seedPhrase');
    setSeedPhrase(Array(12).fill(''));
    setPrivateKey('');
    setCustomWalletName('');
    setIsCustomWallet(true);
    setIsViewMode(false);
    setWalletAction('edit');

    // Close the wallet selection popup and open the detail modal
    setShowWalletPopup(false);
    setShowWalletDetailModal(true);
  };

  const handleCustomWalletSubmit = () => {
    if (activeWalletId && customWalletName && !seedPhrase.some(word => !word) && privateKey) {
      // Create a new custom wallet
      const newWallet: Wallet = {
        id: activeWalletId,
        name: customWalletName,
        icon: '💼', // Default icon for custom wallets
        address: `0x${Array.from({length: 40}, () => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        seedPhrase: seedPhrase.join(' '),
        privateKey: privateKey // Store the private key exactly as entered
      };

      // Add to context
      addWallet(newWallet);
      setWalletDetailStep('confirmation');
    }
  };

  // Handle registration completion
  const handleRegistrationComplete = () => {
    setShowRegistration(false);
  };

  return (
    <div className="min-h-screen bg-[#000000] text-white">
      {/* Show registration modal if user is not registered */}
      {showRegistration && (
        <UserRegistration onComplete={handleRegistrationComplete} />
      )}

      {/* Floating Navigation Bar */}
      <div className="fixed top-6 left-0 w-full z-50 flex justify-center">
        <div className="bg-black rounded-full shadow-lg px-6 flex items-center w-[500px] h-[56px] transition-all duration-300 border border-[#3F3A3A] hover:border-[#B026FF]/30 hover:shadow-[0_0_20px_rgba(176,38,255,0.6)]">
          {/* Logo */}
          <div className="flex items-center">
            <a href="/" className="flex items-center gap-2 group">
              <svg width="28" height="28" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" className="transition-transform duration-300 group-hover:rotate-[20deg]">
                <path d="M8 16C8 11.6 11.6 8 16 8C20.4 8 24 11.6 24 16" stroke="#CDA2FC" strokeWidth="3" strokeLinecap="round" className="group-hover:stroke-[#B026FF]"/>
                <path d="M8 24C8 19.6 11.6 16 16 16C20.4 16 24 19.6 24 24" stroke="#CDA2FC" strokeWidth="3" strokeLinecap="round" className="group-hover:stroke-[#B026FF]"/>
                <path d="M8 8C8 3.6 11.6 0 16 0C20.4 0 24 3.6 24 8" stroke="#CDA2FC" strokeWidth="3" strokeLinecap="round" className="group-hover:stroke-[#B026FF]"/>
              </svg>
            </a>
          </div>

          {/* Navigation - Centered */}
          <nav className="flex items-center justify-center flex-grow mx-4">
            <div className="flex items-center space-x-10">
              <button
                onClick={() => setActiveTab('dashboard')}
                className={`px-3 py-1 text-sm font-medium transition-all duration-300 text-[#CDA2FC] hover:text-[#B026FF] hover:scale-105 ${
                  activeTab === 'dashboard' ? 'border-b-2 border-[#CDA2FC]' : ''
                }`}
              >
                Dashboard
              </button>

              <button
                onClick={() => setActiveTab('security')}
                className={`px-3 py-1 text-sm font-medium transition-all duration-300 text-[#CDA2FC] hover:text-[#B026FF] hover:scale-105 ${
                  activeTab === 'security' ? 'border-b-2 border-[#CDA2FC]' : ''
                }`}
              >
                Security
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`px-3 py-1 text-sm font-medium transition-all duration-300 text-[#CDA2FC] hover:text-[#B026FF] hover:scale-105 ${
                  activeTab === 'settings' ? 'border-b-2 border-[#CDA2FC]' : ''
                }`}
              >
                Settings
              </button>
            </div>
          </nav>

          {/* Profile Icon */}
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex items-center justify-center w-7 h-7 text-[#CDA2FC] hover:text-[#B026FF] hover:scale-110 transition-all duration-300 ${
              activeTab === 'profile' ? 'border-b-2 border-[#CDA2FC]' : ''
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </button>
        </div>
      </div>

      {/* UnifiedChain ID Text */}
      <div className="fixed top-6 left-12 z-50 flex flex-col justify-center h-[56px]">
        <h1 className="text-3xl font-bold text-[#CDA2FC]">UnifiedChain ID</h1>
        <p className="text-sm text-[#CDA2FC]/70">
          {activeTab === 'dashboard' && 'Dashboard'}
          {activeTab === 'security' && 'Security'}
          {activeTab === 'settings' && 'Settings'}
          {activeTab === 'profile' && 'Profile'}
        </p>
      </div>

      {/* Content */}
      <div className="pt-20 pl-12 max-w-7xl">
        {activeTab === 'dashboard' && (
          <div className="animate-fadeIn">
            <div className="mt-12">
              <div className="bg-gray-800/50 p-6 rounded-lg border border-[#3F3A3A] w-[600px] h-[169.6px] transition-all duration-300 hover:border-[#B026FF]/30 hover:shadow-[0_0_20px_rgba(176,38,255,0.6)]">
                <div className="flex flex-col h-full justify-between">
                  <div>
                    <h2 className="text-2xl font-semibold mb-4 text-[#CDA2FC]">{userName || "Guest User"}</h2>
                    <div className="flex items-center">
                      <div className="bg-gray-700/50 px-4 py-2 rounded-md flex items-center">
                        <span className="text-sm font-mono text-[#CDA2FC] mr-2">UID:</span>
                        <p className="text-sm font-mono text-[#CDA2FC]">
                          {showUid ? (
                            uid || "Not Generated"
                          ) : (
                            "••••••••••••••••••"
                          )}
                        </p>
                        <button
                          onClick={() => setShowUid(!showUid)}
                          className="ml-3 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                        >
                          {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="flex items-center">
                      <div className="w-3 h-3 bg-green-400 rounded-full mr-2"></div>
                      <span className="text-green-400 text-sm">Active</span>
                    </div>
                    <span className="mx-3 text-gray-500">•</span>
                    <span className="text-gray-300 text-sm">Unified Chain Identity</span>
                  </div>
                </div>
              </div>

              {/* Horizontal line with curved edges */}
              <div className="mt-4 relative">
                <hr className="border-none h-[3px] mx-auto w-[1450px] bg-[#B026FF]/70 shadow-[0_0_10px_rgba(176,38,255,0.6)] transition-all duration-300 hover:shadow-[0_0_15px_rgba(176,38,255,0.8)] hover:bg-[#B026FF]/90" />
              </div>

              {/* Connected Wallets section with Add Wallet button */}
              <div className="mt-24 flex justify-between items-center w-full" style={{ paddingLeft: "8px", paddingRight: "0" }}>
                <div className="w-[182.06px] h-[36px] flex items-center">
                  <h2 className="text-[#CDA2FC] text-xl font-semibold">Connected Wallets</h2>
                </div>
                <div className="group relative">
                  <button
                    onClick={() => setShowWalletPopup(true)}
                    className="w-10 h-10 rounded-full bg-[#CDA2FC]/70 flex items-center justify-center transition-all duration-300 hover:bg-[#B026FF]/70 hover:shadow-[0_0_15px_rgba(176,38,255,0.6)]"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#B026FF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="transition-all duration-300 group-hover:stroke-white">
                      <line x1="12" y1="5" x2="12" y2="19"></line>
                      <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                  </button>
                  <div className="absolute right-0 top-12 bg-black px-3 py-1 rounded text-[#CDA2FC] text-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap">
                    Add Wallets
                  </div>
                </div>
              </div>

              {/* Connected Wallets List */}
              <div className="mt-6 space-y-4">
                {connectedWallets.length === 0 ? (
                  <div className="bg-[#111111]/50 border border-dashed border-[#B026FF]/30 rounded-lg p-6 flex flex-col items-center justify-center w-[400px] h-[150px]">
                    <p className="text-[#CDA2FC] text-sm mb-2">No wallets connected</p>
                    <button
                      onClick={() => setShowWalletPopup(true)}
                      className="px-4 py-2 bg-[#B026FF]/10 text-[#CDA2FC] rounded-md hover:bg-[#B026FF]/20 transition-all duration-300 text-sm flex items-center gap-2"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <line x1="12" y1="5" x2="12" y2="19"></line>
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                      </svg>
                      Connect Wallet
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {connectedWallets.map((wallet) => (
                      <div
                        key={wallet.id}
                        onClick={() => openWalletDetails(wallet.id)}
                        className="bg-[#111111]/50 border border-[#B026FF]/30 rounded-lg p-4 flex items-center justify-between w-[400px] transition-all duration-300 hover:shadow-[0_0_15px_rgba(176,38,255,0.3)] hover:border-[#B026FF]/50 cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-2xl">{wallet.icon}</div>
                          <div>
                            <h3 className="text-[#CDA2FC] font-medium">{wallet.name}</h3>
                            <p className="text-gray-400 text-xs font-mono">
                              {wallet.privateKey
                                ? `${wallet.privateKey.substring(0, 6)}...${wallet.privateKey.substring(wallet.privateKey.length - 4)}`
                                : `${wallet.address.substring(0, 6)}...${wallet.address.substring(wallet.address.length - 4)}`}
                            </p>
                          </div>
                        </div>
                        <div className="relative">
                          <button
                            className="text-gray-400 hover:text-[#CDA2FC] transition-colors"
                            onClick={(e) => toggleWalletMenu(wallet.id, e)}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="1"></circle>
                              <circle cx="19" cy="12" r="1"></circle>
                              <circle cx="5" cy="12" r="1"></circle>
                            </svg>
                          </button>

                          {/* Dropdown Menu */}
                          {menuOpenWalletId === wallet.id && (
                            <div className="absolute right-0 mt-2 w-36 bg-[#111111] border border-[#B026FF]/30 rounded-md shadow-lg z-10 overflow-hidden">
                              <ul>
                                <li>
                                  <button
                                    className="w-full text-left px-4 py-2 text-[#CDA2FC] hover:bg-[#B026FF]/10 transition-colors"
                                    onClick={(e) => handleWalletAction('show', wallet.id, e)}
                                  >
                                    Show
                                  </button>
                                </li>
                                <li>
                                  <button
                                    className="w-full text-left px-4 py-2 text-[#CDA2FC] hover:bg-[#B026FF]/10 transition-colors"
                                    onClick={(e) => handleWalletAction('edit', wallet.id, e)}
                                  >
                                    Edit
                                  </button>
                                </li>
                                <li>
                                  <button
                                    className="w-full text-left px-4 py-2 text-red-400 hover:bg-red-500/10 transition-colors"
                                    onClick={(e) => handleWalletAction('remove', wallet.id, e)}
                                  >
                                    Remove
                                  </button>
                                </li>
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="animate-fadeIn">
            <div className="bg-gray-800/50 p-6 rounded-lg border border-purple-900/30">
              <h2 className="text-xl font-semibold mb-4 text-[#CDA2FC]">Security Settings</h2>
              <p className="text-gray-300 mb-6">Manage your security preferences and authentication methods.</p>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-[#CDA2FC]">Face Authentication</h3>
                    <p className="text-sm text-gray-400">Secure your account with facial recognition</p>
                  </div>
                  <button
                    onClick={toggleFaceAuth}
                    className="relative inline-block w-12 h-6 rounded-full bg-gray-700"
                  >
                    <div
                      className={`absolute w-4 h-4 rounded-full transition-transform ${
                        faceAuthEnabled
                          ? 'left-7 top-1 bg-purple-500'
                          : 'left-1 top-1 bg-gray-400'
                      }`}
                    ></div>
                  </button>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-[#CDA2FC]">Biometric Verification</h3>
                    <p className="text-sm text-gray-400">Use biometric data for enhanced security</p>
                  </div>
                  <div className="relative inline-block w-12 h-6 rounded-full bg-gray-700">
                    <div className="absolute left-1 top-1 w-4 h-4 rounded-full bg-gray-400 transition-transform"></div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-[#CDA2FC]">Password</h3>
                    <p className="text-sm text-gray-400">Protect your account with a strong password</p>
                  </div>
                  <button
                    onClick={togglePassword}
                    className="relative inline-block w-12 h-6 rounded-full bg-gray-700"
                  >
                    <div
                      className={`absolute w-4 h-4 rounded-full transition-transform ${
                        passwordEnabled
                          ? 'left-7 top-1 bg-purple-500'
                          : 'left-1 top-1 bg-gray-400'
                      }`}
                    ></div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="animate-fadeIn">
            <div className="bg-gray-800/50 p-6 rounded-lg border border-purple-900/30">
              <h2 className="text-xl font-semibold mb-4 text-[#CDA2FC]">Account Settings</h2>
              <p className="text-gray-300 mb-6">Manage your account preferences and connected services.</p>

              <div className="space-y-6">
                <div className="bg-gray-700/30 p-4 rounded-lg border border-[#B026FF]/20 hover:border-[#B026FF]/40 transition-all duration-300">
                  <h3 className="text-lg font-medium text-[#CDA2FC] mb-2">Change Password</h3>
                  <p className="text-sm text-gray-400 mb-4">Update your account password for enhanced security</p>
                  <button
                    onClick={openChangePasswordModal}
                    className="px-4 py-2 bg-[#B026FF]/70 text-white rounded-md hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)] transition-all duration-300"
                  >
                    Change Password
                  </button>
                </div>

                <div className="bg-gray-700/30 p-4 rounded-lg border border-[#B026FF]/20 hover:border-[#B026FF]/40 transition-all duration-300">
                  <h3 className="text-lg font-medium text-[#CDA2FC] mb-2">Reveal Your Seed Phrase</h3>
                  <p className="text-sm text-gray-400 mb-4">View your seed phrase after password verification</p>
                  <button
                    onClick={openSeedPhraseModal}
                    className="px-4 py-2 bg-[#B026FF]/70 text-white rounded-md hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)] transition-all duration-300"
                  >
                    Reveal Seed Phrase
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="animate-fadeIn">
            <div className="bg-gray-800/50 p-6 rounded-lg border border-purple-900/30">
              <div className="flex flex-col items-center mb-6">
                <div className="w-24 h-24 bg-gray-700 rounded-full flex items-center justify-center mb-4">
                  <User size={48} className="text-gray-400" />
                </div>
                <h2 className="text-xl font-semibold text-[#CDA2FC]">{userName || "Guest User"}</h2>
                <div className="flex items-center mt-2">
                  <div className="bg-gray-700/50 px-4 py-2 rounded-md flex items-center">
                    <span className="text-sm font-mono text-[#CDA2FC] mr-2">UID:</span>
                    <p className="text-sm font-mono text-[#CDA2FC]">
                      {showUid ? (
                        uid || "Not Generated"
                      ) : (
                        "••••••••••••••••••"
                      )}
                    </p>
                    <button
                      onClick={() => setShowUid(!showUid)}
                      className="ml-3 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                    >
                      {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-4 text-[#CDA2FC]">QR Code Scanner</h3>
                  <div className="flex flex-col items-center space-y-4">
                    <div className="grid grid-cols-2 gap-4 w-full">
                      <div
                        className="bg-gray-700/50 p-6 rounded-lg border border-[#B026FF]/20 hover:border-[#B026FF]/40 transition-all duration-300 flex flex-col items-center justify-center cursor-pointer"
                        onClick={openQrScanner}
                      >
                        <Scan size={48} className="text-[#CDA2FC] mb-3" />
                        <p className="text-[#CDA2FC] text-center">Scan QR Code</p>
                      </div>

                      <div
                        className="bg-gray-700/50 p-6 rounded-lg border border-[#B026FF]/20 hover:border-[#B026FF]/40 transition-all duration-300 flex flex-col items-center justify-center cursor-pointer"
                        onClick={openQrGenerator}
                      >
                        <QrCode size={48} className="text-[#CDA2FC] mb-3" />
                        <p className="text-[#CDA2FC] text-center">Generate QR Code</p>
                      </div>
                    </div>

                    <p className="text-sm text-gray-400 text-center mt-2">
                      Scan a QR code to import account details or generate a QR code to share your account.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Wallet Selection Popup */}
      {showWalletPopup && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-[#111111] w-[450px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Popup Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">
                {walletSelectionStep === 'select' ? 'Select Wallet' : 'Search Wallets'}
              </h3>
              <button
                onClick={() => {
                  setShowWalletPopup(false);
                  setWalletSelectionStep('select');
                  setSelectedWallet(null);
                }}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Popup Content */}
            <div className="p-6">
              {walletSelectionStep === 'select' ? (
                <div className="flex flex-col">
                  <button
                    onClick={() => setWalletSelectionStep('search')}
                    className="w-full py-3 px-4 bg-[#1A1A1A] hover:bg-[#CDA2FC]/10 text-[#CDA2FC] rounded-md flex justify-between items-center transition-all duration-300 hover:shadow-[0_0_10px_rgba(176,38,255,0.3)]"
                  >
                    <span>Select Wallet</span>
                    <ChevronDown size={18} />
                  </button>
                </div>
              ) : (
                <div className="flex flex-col">
                  {/* Search Input */}
                  <div className="relative mb-4">
                    <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#CDA2FC]">
                      <Search size={18} />
                    </div>
                    <input
                      type="text"
                      placeholder="Search wallets..."
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-2 pl-10 pr-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                  </div>

                  {/* Wallet List */}
                  <div className="max-h-[300px] overflow-y-auto">
                    {walletOptions.map((wallet) => (
                      <button
                        key={wallet.id}
                        onClick={() => setSelectedWallet(wallet.id)}
                        className={`w-full py-3 px-4 rounded-md flex items-center gap-3 transition-all duration-300 mb-2 ${
                          selectedWallet === wallet.id
                            ? 'bg-[#B026FF]/20 text-white'
                            : 'bg-[#1A1A1A] text-[#CDA2FC] hover:bg-[#CDA2FC]/10'
                        }`}
                      >
                        <span className="text-xl">{wallet.icon}</span>
                        <span>{wallet.name}</span>
                      </button>
                    ))}
                  </div>

                  {/* Not Listed Wallets Link */}
                  <div className="mt-4 text-right">
                    <button
                      onClick={handleNotListedWallet}
                      className="text-[#CDA2FC] text-sm hover:text-[#B026FF] transition-colors"
                    >
                      Not listed wallet?
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Popup Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={() => {
                  if (walletSelectionStep === 'select') {
                    setShowWalletPopup(false);
                  } else {
                    setWalletSelectionStep('select');
                  }
                }}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  if (walletSelectionStep === 'select') {
                    setWalletSelectionStep('search');
                  } else if (selectedWallet) {
                    // Connect the selected wallet
                    connectWallet(selectedWallet);
                  }
                }}
                disabled={walletSelectionStep === 'search' && !selectedWallet}
                className={`px-4 py-2 rounded-md transition-all duration-300 ${
                  walletSelectionStep === 'search' && !selectedWallet
                    ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                    : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                }`}
              >
                {walletSelectionStep === 'select' ? 'Next' : 'Connect'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Face Authentication Modal */}
      {showFaceAuthModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">
                {faceAuthStep === 'scan' && 'Face Authentication Setup'}
                {faceAuthStep === 'processing' && 'Processing...'}
                {faceAuthStep === 'success' && 'Authentication Successful'}
                {faceAuthStep === 'error' && 'Authentication Failed'}
              </h3>
              <button
                onClick={closeFaceAuthModal}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {faceAuthStep === 'scan' && (
                <div className="flex flex-col items-center">
                  <p className="text-gray-300 mb-4 text-center">
                    Position your face in the center of the frame and ensure good lighting.
                  </p>

                  <div className="relative w-[320px] h-[240px] bg-gray-900 rounded-lg overflow-hidden mb-4 border-2 border-[#B026FF]/30">
                    <video
                      ref={webcamRef as React.RefObject<HTMLVideoElement>}
                      className="w-full h-full object-cover"
                      autoPlay
                      playsInline
                      muted
                    />
                    <div className="absolute inset-0 border-4 border-dashed border-[#B026FF]/40 pointer-events-none rounded-lg"></div>
                  </div>

                  <p className="text-sm text-gray-400 mb-4 text-center">
                    Your face data will be securely stored and encrypted.
                  </p>
                </div>
              )}

              {faceAuthStep === 'processing' && (
                <div className="flex flex-col items-center py-8">
                  <div className="w-16 h-16 mb-4 flex items-center justify-center">
                    <Loader size={48} className="text-[#B026FF] animate-spin" />
                  </div>
                  <p className="text-gray-300 text-center">
                    Analyzing facial features and creating secure biometric template...
                  </p>
                </div>
              )}

              {faceAuthStep === 'success' && (
                <div className="flex flex-col items-center py-8">
                  <div className="w-16 h-16 bg-[#B026FF]/20 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle size={48} className="text-green-500" />
                  </div>
                  <p className="text-gray-300 text-center">
                    Face authentication has been successfully set up!
                  </p>
                </div>
              )}

              {faceAuthStep === 'error' && (
                <div className="flex flex-col items-center py-8">
                  <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-4">
                    <AlertCircle size={48} className="text-red-500" />
                  </div>
                  <p className="text-gray-300 text-center mb-2">
                    We couldn't authenticate your face.
                  </p>
                  <p className="text-sm text-gray-400 text-center">
                    Please ensure good lighting and position your face clearly in the frame.
                  </p>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              {faceAuthStep === 'scan' && (
                <>
                  <button
                    onClick={closeFaceAuthModal}
                    className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={captureAndVerifyFace}
                    className="px-4 py-2 rounded-md bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)] transition-all duration-300"
                  >
                    Capture & Verify
                  </button>
                </>
              )}

              {faceAuthStep === 'processing' && (
                <button
                  disabled
                  className="px-4 py-2 rounded-md bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed"
                >
                  Processing...
                </button>
              )}

              {faceAuthStep === 'error' && (
                <>
                  <button
                    onClick={closeFaceAuthModal}
                    className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => setFaceAuthStep('scan')}
                    className="px-4 py-2 rounded-md bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)] transition-all duration-300"
                  >
                    Try Again
                  </button>
                </>
              )}

              {faceAuthStep === 'success' && (
                <button
                  onClick={closeFaceAuthModal}
                  className="px-4 py-2 rounded-md bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)] transition-all duration-300"
                >
                  Done
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Password Setup Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">Set Password</h3>
              <button
                onClick={closePasswordModal}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <p className="text-gray-300 mb-4">Create a strong password to secure your account.</p>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Password</label>
                  <div className="relative">
                    <input
                      type={showUid ? "text" : "password"}
                      value={password}
                      onChange={handlePasswordInput}
                      placeholder="Enter your password"
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                    <button
                      onClick={() => setShowUid(!showUid)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                    >
                      {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>

                  {/* Password requirements */}
                  <div className="mt-2 space-y-1">
                    <p className={`text-xs ${passwordErrors.length ? 'text-red-400' : 'text-green-400'}`}>
                      {passwordErrors.length ? '✗' : '✓'} Minimum 6 characters
                    </p>
                    <p className={`text-xs ${passwordErrors.uppercase ? 'text-red-400' : 'text-green-400'}`}>
                      {passwordErrors.uppercase ? '✗' : '✓'} At least 1 capital letter
                    </p>
                    <p className={`text-xs ${passwordErrors.number ? 'text-red-400' : 'text-green-400'}`}>
                      {passwordErrors.number ? '✗' : '✓'} At least 1 number
                    </p>
                    <p className={`text-xs ${passwordErrors.special ? 'text-red-400' : 'text-green-400'}`}>
                      {passwordErrors.special ? '✗' : '✓'} At least 1 special character
                    </p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Confirm Password</label>
                  <div className="relative">
                    <input
                      type={showUid ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Confirm your password"
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                  </div>
                  {confirmPassword && password !== confirmPassword && (
                    <p className="text-red-400 text-xs mt-1">Passwords do not match</p>
                  )}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closePasswordModal}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handlePasswordSubmit}
                disabled={password.length < 8 || password !== confirmPassword}
                className={`px-4 py-2 rounded-md transition-all duration-300 ${
                  password.length < 8 || password !== confirmPassword
                    ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                    : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                }`}
              >
                Save Password
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Wallet Detail Modal */}
      {showWalletDetailModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">
                {walletDetailStep === 'seedPhrase' && (
                  isViewMode ? 'View Seed Phrase' : (walletAction === 'edit' ? 'Edit Seed Phrase' : 'Add Seed Phrase')
                )}
                {walletDetailStep === 'privateKey' && (
                  isViewMode ? 'View Private Key' : (walletAction === 'edit' ? 'Edit Private Key' : 'Add Private Key')
                )}
                {walletDetailStep === 'confirmation' && 'Wallet Setup Complete'}
              </h3>
              <div className="flex items-center gap-3">
                {(walletAction === 'show' || walletAction === 'edit') && walletDetailStep !== 'confirmation' && (
                  <button
                    onClick={toggleEditMode}
                    className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors text-sm"
                  >
                    {isViewMode ? 'Edit' : 'View Only'}
                  </button>
                )}
                <button
                  onClick={closeWalletDetailModal}
                  className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {walletDetailStep === 'seedPhrase' && (
                <div className="flex flex-col">
                  {isCustomWallet && (
                    <div className="mb-6">
                      <label className="block text-gray-300 mb-2">Wallet Name</label>
                      <input
                        type="text"
                        value={customWalletName}
                        onChange={(e) => setCustomWalletName(e.target.value)}
                        placeholder="Enter wallet name"
                        className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30 mb-4"
                      />
                    </div>
                  )}

                  <p className="text-gray-300 mb-4">Enter your 12-word seed phrase to recover your wallet.</p>

                  <div className="grid grid-cols-3 gap-3 mb-6">
                    {seedPhrase.map((word, index) => (
                      <div key={index} className="flex items-center">
                        <span className="text-gray-500 text-xs mr-2 w-5">{index + 1}.</span>
                        <input
                          type="text"
                          value={word}
                          onChange={(e) => handleSeedPhraseChange(index, e.target.value)}
                          readOnly={isViewMode}
                          className={`w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-2 px-3 text-[#CDA2FC] text-sm ${
                            isViewMode
                              ? 'opacity-80 cursor-not-allowed'
                              : 'focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30'
                          }`}
                        />
                      </div>
                    ))}
                  </div>

                  <div className="text-gray-400 text-sm mb-4">
                    <p>Make sure to enter your seed phrase in the correct order.</p>
                  </div>
                </div>
              )}

              {walletDetailStep === 'privateKey' && (
                <div className="flex flex-col">
                  <p className="text-gray-300 mb-4">Enter your private key to complete the wallet setup.</p>

                  <div className="mb-6">
                    <div className="relative">
                      <input
                        type={showUid ? "text" : "password"}
                        value={privateKey}
                        onChange={(e) => !isViewMode && setPrivateKey(e.target.value)}
                        placeholder="Enter your private key"
                        readOnly={isViewMode}
                        className={`w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] ${
                          isViewMode
                            ? 'opacity-80 cursor-not-allowed'
                            : 'focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30'
                        }`}
                      />
                      <button
                        onClick={() => setShowUid(!showUid)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                      >
                        {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className="text-gray-400 text-sm mb-4">
                    <p>Your private key is encrypted and securely stored.</p>
                  </div>
                </div>
              )}

              {walletDetailStep === 'confirmation' && (
                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-[#B026FF]/20 rounded-full flex items-center justify-center mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#B026FF" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                      <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                  </div>

                  <h4 className="text-[#CDA2FC] text-lg font-medium mb-2">Wallet Setup Complete</h4>
                  <p className="text-gray-400 text-center mb-4">
                    {isCustomWallet
                      ? `Your custom wallet "${customWalletName}" has been successfully added with the provided seed phrase and private key.`
                      : 'Your wallet has been successfully set up with the provided seed phrase and private key.'
                    }
                  </p>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeWalletDetailModal}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                {walletDetailStep === 'confirmation' ? 'Close' : 'Cancel'}
              </button>

              {walletDetailStep !== 'confirmation' && (
                <button
                  onClick={() => {
                    if (walletDetailStep === 'seedPhrase') {
                      handleSeedPhraseSubmit();
                    } else if (walletDetailStep === 'privateKey') {
                      if (isCustomWallet) {
                        handleCustomWalletSubmit();
                      } else {
                        handlePrivateKeySubmit();
                      }
                    }
                  }}
                  disabled={
                    (isViewMode && walletDetailStep === 'privateKey') ||
                    (!isViewMode && walletDetailStep === 'seedPhrase' && seedPhrase.some(word => !word)) ||
                    (walletDetailStep === 'seedPhrase' && isCustomWallet && !customWalletName) ||
                    (walletDetailStep === 'privateKey' && !privateKey)
                  }
                  className={`px-4 py-2 rounded-md transition-all duration-300 ${
                    (isViewMode && walletDetailStep === 'privateKey') ||
                    (!isViewMode && walletDetailStep === 'seedPhrase' && seedPhrase.some(word => !word)) ||
                    (walletDetailStep === 'seedPhrase' && isCustomWallet && !customWalletName) ||
                    (walletDetailStep === 'privateKey' && !privateKey)
                      ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                      : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                  }`}
                >
                  {isViewMode ? 'Next' : (walletAction === 'edit' ? 'Save' : 'Next')}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {showChangePasswordModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">Change Password</h3>
              <button
                onClick={closeChangePasswordModal}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <p className="text-gray-300 mb-4">Enter your current password and create a new password.</p>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Current Password</label>
                  <div className="relative">
                    <input
                      type={showUid ? "text" : "password"}
                      value={currentPassword}
                      onChange={(e) => {
                        setCurrentPassword(e.target.value);
                        setCurrentPasswordError(null); // Clear error when user types
                      }}
                      placeholder="Enter your current password"
                      className={`w-full bg-[#1A1A1A] border ${currentPasswordError ? 'border-red-500' : 'border-[#B026FF]/20'} rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30`}
                    />
                    <button
                      onClick={() => setShowUid(!showUid)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                    >
                      {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                  {currentPasswordError && (
                    <p className="text-red-400 text-xs mt-1">{currentPasswordError}</p>
                  )}

                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">New Password</label>
                  <div className="relative">
                    <input
                      type={showUid ? "text" : "password"}
                      value={newPassword}
                      onChange={handleNewPasswordInput}
                      placeholder="Enter your new password"
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                  </div>

                  {/* Password requirements */}
                  <div className="mt-2 space-y-1">
                    <p className={`text-xs ${newPasswordErrors.length ? 'text-red-400' : 'text-green-400'}`}>
                      {newPasswordErrors.length ? '✗' : '✓'} Minimum 6 characters
                    </p>
                    <p className={`text-xs ${newPasswordErrors.uppercase ? 'text-red-400' : 'text-green-400'}`}>
                      {newPasswordErrors.uppercase ? '✗' : '✓'} At least 1 capital letter
                    </p>
                    <p className={`text-xs ${newPasswordErrors.number ? 'text-red-400' : 'text-green-400'}`}>
                      {newPasswordErrors.number ? '✗' : '✓'} At least 1 number
                    </p>
                    <p className={`text-xs ${newPasswordErrors.special ? 'text-red-400' : 'text-green-400'}`}>
                      {newPasswordErrors.special ? '✗' : '✓'} At least 1 special character
                    </p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Confirm New Password</label>
                  <div className="relative">
                    <input
                      type={showUid ? "text" : "password"}
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="Confirm your new password"
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                  </div>
                  {confirmNewPassword && newPassword !== confirmNewPassword && (
                    <p className="text-red-400 text-xs mt-1">Passwords do not match</p>
                  )}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeChangePasswordModal}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handleChangePasswordSubmit}
                disabled={!currentPassword || newPassword.length < 8 || newPassword !== confirmNewPassword}
                className={`px-4 py-2 rounded-md transition-all duration-300 ${
                  !currentPassword || newPassword.length < 8 || newPassword !== confirmNewPassword
                    ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                    : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                }`}
              >
                Update Password
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reveal Seed Phrase Modal */}
      {showSeedPhraseModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">
                {isPasswordVerified ? 'Your Seed Phrase' : 'Password Verification'}
              </h3>
              <button
                onClick={closeSeedPhraseModal}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {!isPasswordVerified ? (
                <div className="flex flex-col">
                  <p className="text-gray-300 mb-4">Enter your password to reveal your seed phrase.</p>
                  {!userPassword ? (
                    <div className="mb-6">
                      <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-md p-3 mb-4">
                        <p className="text-yellow-400 text-sm">
                          You need to set a password in the Security section before you can view your seed phrase.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="mb-6">
                      <div className="relative">
                        <input
                          type={showUid ? "text" : "password"}
                          value={seedPhrasePassword}
                          onChange={(e) => setSeedPhrasePassword(e.target.value)}
                          placeholder="Enter your password"
                          className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                        />
                        <button
                          onClick={() => setShowUid(!showUid)}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                        >
                          {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col">
                  <p className="text-gray-300 mb-4">This is your seed phrase. Keep it safe and never share it with anyone.</p>

                  <div className="bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md p-4 mb-4">
                    <div className="grid grid-cols-3 gap-3">
                      {storedSeedPhrase.split(' ').map((word, index) => (
                        <div key={index} className="flex items-center">
                          <span className="text-gray-500 text-xs mr-2 w-5">{index + 1}.</span>
                          <span className="text-[#CDA2FC] text-sm">{word}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-red-500/10 border border-red-500/30 rounded-md p-3 mb-4">
                    <p className="text-red-400 text-sm">
                      Warning: Never share your seed phrase with anyone. Anyone with your seed phrase can access your wallets and funds.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeSeedPhraseModal}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                {isPasswordVerified ? 'Close' : 'Cancel'}
              </button>

              {!isPasswordVerified && (
                <button
                  onClick={verifySeedPhrasePassword}
                  disabled={!seedPhrasePassword || !userPassword || seedPhrasePassword !== userPassword}
                  className={`px-4 py-2 rounded-md transition-all duration-300 ${
                    !seedPhrasePassword || !userPassword || seedPhrasePassword !== userPassword
                      ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                      : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                  }`}
                >
                  Verify Password
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* QR Code Scanner Modal */}
      {showQrScanner && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">Scan QR Code</h3>
              <button
                onClick={closeQrScanner}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <div className="flex flex-col items-center">
                <p className="text-gray-300 mb-4 text-center">Position the QR code within the scanner area.</p>

                <div ref={scannerRef} className="w-full mb-6">
                  <div id="qr-reader" className="w-full"></div>
                </div>

                <div className="w-full space-y-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">UID</label>
                    <input
                      type="text"
                      value={uidInput}
                      onChange={(e) => setUidInput(e.target.value)}
                      placeholder="Enter UID"
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">Seed Phrase</label>
                    <textarea
                      value={seedPhraseInput}
                      onChange={(e) => setSeedPhraseInput(e.target.value)}
                      placeholder="Enter seed phrase"
                      rows={3}
                      className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeQrScanner}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handleUidSubmit}
                disabled={!uidInput || !seedPhraseInput}
                className={`px-4 py-2 rounded-md transition-all duration-300 ${
                  !uidInput || !seedPhraseInput
                    ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                    : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                }`}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Generator Modal */}
      {showQrGenerator && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">Your QR Code</h3>
              <button
                onClick={closeQrGenerator}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <div className="flex flex-col items-center">
                <p className="text-gray-300 mb-4 text-center">Scan this QR code to share your account details.</p>

                <div className="bg-white p-4 rounded-lg mb-4">
                  <QRCode
                    value={`UID:7F9A2B4E5C8D1H6J3K|SEED:${storedSeedPhrase}`}
                    size={200}
                    level="H"
                  />
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-md p-3 mb-4 w-full">
                  <p className="text-yellow-400 text-sm">
                    Warning: This QR code contains sensitive information. Only share it with trusted devices.
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeQrGenerator}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Wallet Authentication Modal */}
      {showWalletAuthModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">Authentication Required</h3>
              <button
                onClick={closeWalletAuthModal}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <div className="flex flex-col">
                <p className="text-gray-300 mb-4">Enter your password to access wallet details.</p>
                {!userPassword ? (
                  <div className="mb-6">
                    <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-md p-3 mb-4">
                      <p className="text-yellow-400 text-sm">
                        You need to set a password in the Security section before you can access wallet details.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="mb-6">
                    <div className="relative">
                      <input
                        type={showUid ? "text" : "password"}
                        value={walletAuthPassword}
                        onChange={(e) => setWalletAuthPassword(e.target.value)}
                        placeholder="Enter your password"
                        className="w-full bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md py-3 px-4 text-[#CDA2FC] focus:outline-none focus:border-[#B026FF]/50 focus:ring-1 focus:ring-[#B026FF]/30"
                      />
                      <button
                        onClick={() => setShowUid(!showUid)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                      >
                        {showUid ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>
                )}

                {/* Biometric option */}
                {faceAuthEnabled && (
                  <div className="flex items-center justify-center mb-4">
                    <button
                      onClick={() => {
                        // Close this modal and open face auth modal
                        setShowWalletAuthModal(false);
                        setShowFaceAuthModal(true);
                        setFaceAuthStep('scan');
                        // Create a new webcam reference
                        setWebcamRef(React.createRef<HTMLVideoElement>());
                      }}
                      className="flex items-center gap-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
                    >
                      <Camera size={16} />
                      <span>Use Face Authentication Instead</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeWalletAuthModal}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handleWalletAuth}
                disabled={!walletAuthPassword || !userPassword || walletAuthPassword !== userPassword}
                className={`px-4 py-2 rounded-md transition-all duration-300 ${
                  !walletAuthPassword || !userPassword || walletAuthPassword !== userPassword
                    ? 'bg-[#B026FF]/30 text-[#CDA2FC]/50 cursor-not-allowed'
                    : 'bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]'
                }`}
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Scan Result Modal */}
      {showScanResultModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-[#111111] w-[500px] rounded-lg border border-[#B026FF]/30 shadow-[0_0_20px_rgba(176,38,255,0.4)] overflow-hidden">
            {/* Modal Header */}
            <div className="flex justify-between items-center p-4 border-b border-[#B026FF]/20">
              <h3 className="text-[#CDA2FC] text-lg font-semibold">Scan Result</h3>
              <button
                onClick={closeScanResultModal}
                className="text-[#CDA2FC] hover:text-[#B026FF] transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              <div className="flex flex-col">
                <p className="text-gray-300 mb-4">The following data was scanned from the QR code:</p>

                <div className="bg-[#1A1A1A] border border-[#B026FF]/20 rounded-md p-4 mb-4">
                  <p className="text-[#CDA2FC] break-all">{scanResult}</p>
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-md p-3 mb-4">
                  <p className="text-yellow-400 text-sm">
                    Verify that this information is correct before proceeding.
                  </p>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-[#B026FF]/20 flex justify-end">
              <button
                onClick={closeScanResultModal}
                className="px-4 py-2 text-[#CDA2FC] hover:text-[#B026FF] transition-colors mr-2"
              >
                Cancel
              </button>
              <button
                onClick={handleScanResultSubmit}
                className="px-4 py-2 rounded-md transition-all duration-300 bg-[#B026FF]/70 text-white hover:bg-[#B026FF] hover:shadow-[0_0_10px_rgba(176,38,255,0.6)]"
              >
                Process Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
